def lambda_handler(event, context):
    return {
        "message": f"Hello ${event['Payload']['Input']['name']}"
    }
